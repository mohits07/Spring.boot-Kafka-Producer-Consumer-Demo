package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Trainee;

public interface EmployeeRepository extends CrudRepository<Trainee, Integer> {

}