package com.cg.bean;

public class User1 {

	private String firstname;
	private String lastname;
	private String address;
	private String shopping_interest;

	public User1(String firstname ,  String lastname, String address, String shopping_interest) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.shopping_interest = shopping_interest;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getShopping_interest() {
		return shopping_interest;
	}

	public void setShopping_interest(String shopping_interest) {
		this.shopping_interest = shopping_interest;
	}

}
