package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Inventory;

public interface Repository extends CrudRepository<Inventory, Integer> {

}
