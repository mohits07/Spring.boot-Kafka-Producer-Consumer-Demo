package com.cg.controller;

import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Inventory;
import com.cg.repo.Repository;
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ReturnGoodsController {
	
		@Autowired
		private Repository repo;

		@GetMapping(path = "/all", produces = "application/json")
		public Iterable<Inventory> getAll() {
			Iterable<Inventory> i = repo.findAll();
			return i;
		}
		 
		/*@GetMapping(path = "/Inventory/{id}")
		public ResponseEntity<Inventory> get(@PathVariable("id") int id) {
			try {
				Optional<Inventory> result = repo.findById(id);
				Inventory i = result.get();
				return new ResponseEntity<Inventory>(i, HttpStatus.OK);
			} catch (NoSuchElementException e) {
				return new ResponseEntity("Sorry. No Inventory Found", HttpStatus.NOT_FOUND);
			}
		}*/

		@PostMapping(path = "/add", consumes = "application/json", produces = "application/json")
		public Inventory add(@RequestBody Inventory i) {

			repo.save(i);
			return i;
		}

		@PutMapping(path = "/update", consumes = "application/json")
		public Inventory edit(@RequestBody Inventory i) {
			repo.save(i);
			return i;
		}
	}


