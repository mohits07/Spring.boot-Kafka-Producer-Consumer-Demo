package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Album;
import com.cg.service.AlbumService;

@RestController
public class AlbumController {

	@Autowired
	 private AlbumService service;

	@PostMapping("/add")
	public String saveAlbum(@RequestParam("title") String title, @RequestParam("artist") String artist,
			@RequestParam("price") int price) {
		Album a = new Album();
		a.setTitle(title);
		a.setArtist(artist);
		a.setPrice(price);

		service.addAlbum(a);
		return "album saved";

	}

	// gets album by id
	@GetMapping(name ="/album", produces = "application/json")
	public Album getAlbum(@RequestParam("id") int id) {

		Album a = service.getAlbum(id);
		return a;

	}

	// gets all album
	@GetMapping("/all")
	public Iterable<Album> getAll() {
		return service.getAll();
	}

	@PutMapping(path ="/update/{id}", consumes = "application/json")
	public Album updateAlbum(@PathVariable("id") int id, @RequestBody Album a) {
		return service.updateAlbum(a, id);

	}

	@DeleteMapping(path ="/delete/{id}")
	public String delete(@PathVariable("id") int id) {
		return service.deleteAlbum(id);

	}

}
