package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;
import com.cg.repo.AlbumRepo;

@Service
@Transactional
public class AlbumServiceImpl implements AlbumService {

	@Autowired
	 private AlbumRepo repo;

	
	public void addAlbum(Album a) {
		repo.save(a);
	}

	public Album getAlbum(int id) {
		return repo.findById(id).get();
	}

	public Iterable<Album> getAll() {
		return repo.findAll();
	}

	public String deleteAlbum(int id) {
		Album a1 = repo.findById(id).get();
		repo.delete(a1);
		return ("Deleted ");
	}

	public Album updateAlbum(Album a, int id) {
		a.setId(id);
		repo.save(a);
		return a;
	}

}
